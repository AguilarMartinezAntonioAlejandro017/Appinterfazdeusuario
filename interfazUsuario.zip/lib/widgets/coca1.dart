// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';

class Cola extends StatelessWidget {
  const Cola({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<IconoProducto> IconoProductos = [
      IconoProducto(nombre: "Pepsi", icono: 'assets/coca2.png'),
      IconoProducto(nombre: "Sprite", icono: 'assets/coca3.png'),
      IconoProducto(nombre: "Lipton", icono: 'assets/coca4.png'),
      IconoProducto(nombre: "Dr.papper", icono: 'assets/coca5.png'),
    ];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(IconoProductos.length, (index) {
        return Column(
          children: [
            Container(
              width: 80,
              height: 80,
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .primaryContainer
                    .withOpacity(0.4),
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                IconoProductos[index].icono,
              ),
            ),
            const SizedBox(height: 6),
            Text(IconoProductos[index].nombre)
          ],
        );
      }),
    );
  }
}

class IconoProducto {
  final String nombre;
  final String icono;
  IconoProducto({
    required this.nombre,
    required this.icono,
  });
}
