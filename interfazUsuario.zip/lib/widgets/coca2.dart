import 'package:aguilar/modelo/producto.dart';
import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:ionicons/ionicons.dart';

class CocaCola extends StatelessWidget {
  const CocaCola({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(productos.length, (index) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 18),
          child: Row(
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  image: DecorationImage(
                    image: AssetImage(productos[index].imagen),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    productos[index].nombre,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text("600Ml"),
                  const SizedBox(height: 8),
                  Row(
                    children: const [Text("23 Pesos")],
                  )
                ],
              )
            ],
          ),
        );
      }),
    );
  }
}
