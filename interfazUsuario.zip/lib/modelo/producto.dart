// ignore_for_file: public_member_api_docs, sort_constructors_first
class CocaCola {
  final String nombre;
  final String color;
  final int mililitros;
  final int precio;
  final String imagen;
  CocaCola({
    required this.nombre,
    required this.color,
    required this.mililitros,
    required this.precio,
    required this.imagen,
  });
}

final List<CocaCola> productos = [
  CocaCola(
    nombre: "Coca-Cola",
    color: "Rojo",
    mililitros: 600,
    precio: 17,
    imagen: "assets/coca9.jpg",
  ),
  CocaCola(
    nombre: "Power",
    color: "Azul",
    mililitros: 1000,
    precio: 27,
    imagen: "assets/coca10.jpg",
  ),
  CocaCola(
    nombre: "Fanta",
    color: "Naranja",
    mililitros: 355,
    precio: 17,
    imagen: "assets/coca11.jpg",
  ),
];
