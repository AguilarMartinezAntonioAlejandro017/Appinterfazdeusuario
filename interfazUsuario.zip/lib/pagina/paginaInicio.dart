import 'package:aguilar/widgets/coca1.dart';
import 'package:aguilar/widgets/coca2.dart';
import 'package:aguilar/widgets/coca3.dart';
import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';

class PaginaInicio extends StatelessWidget {
  const PaginaInicio({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Hola, Antonio"),
            Text(
              "Buscas algun producto?",
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Ionicons.person_add_outline),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Ionicons.settings),
          ),
        ],
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(14),
        children: [
          const Tarjeta(),
          const SizedBox(height: 20),
          Text(
            "Productos",
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 15),
          const Cola(),
          const SizedBox(height: 25),
          Text(
            "Información de productos",
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 15),
          const CocaCola(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: false,
        showSelectedLabels: false,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Ionicons.home_outline),
            activeIcon: Icon(Ionicons.home),
            label: "Inicio",
          ),
          BottomNavigationBarItem(
            icon: Icon(Ionicons.compass),
            activeIcon: Icon(Ionicons.compass),
            label: "Inicio",
          ),
          BottomNavigationBarItem(
            icon: Icon(Ionicons.person_add),
            label: "Inicio",
            activeIcon: Icon(Ionicons.person_add),
          ),
          BottomNavigationBarItem(
            icon: Icon(Ionicons.person_outline),
            activeIcon: Icon(Ionicons.person),
            label: "Inicio",
          ),
        ],
      ),
    );
  }
}
